%19IM30019
%Rupesh Garg

clc;
clear;
close all;

rng default

n = 5;
D=zeros(n,n);
due_date = [18 6 9 11 8];
processing_time = [6 2 3 4 5];

for i = 1:n
    for j = 1:n
        D(i,j) = due_date(j);
    end
end

    
nVar=n;
tour = [];


%% ACO Parameters

MaxIt=100;      % Maximum Number of Iterations

nAnt=100;        % Number of Ants

tau_initial=100;	% Initial Pheromone

alpha=1;        % Pheromone Exponential Weight
beta=1;         % Heuristic Exponential Weight

evp=0.05;       % Evaporation Rate

%% Initialization
eta=1./D;            

tau=tau_initial*ones(nVar,nVar);   % Phromone Matrix
BestCost=zeros(MaxIt,1);    % Array for Best Cost Values

% Empty Ant
empty_ant.Tour=[];
empty_ant.Cost=[];

% Ant Colony Matrix
ant=repmat(empty_ant,nAnt,1);

% Best Ant
BestSol.Cost=inf;


%% ACO Main Loop

for it=1:MaxIt
    
    % Move Ants
    for k=1:nAnt
        
        % Creating sequence for each ant, by choosing the starting
        % node(job) randomly, and then applying roulette wheel selection
        % for subsequent nodes
        
        % So at the end of the below for loop, the complete sequence of
        % the ant would be constructed
        
        ant(k).Tour=randi([1 nVar]);
        
        for l=2:nVar
            
            i=ant(k).Tour(end);
            
            P=tau(i,:).^alpha.*eta(i,:).^beta;
            
            P(ant(k).Tour)=0; %replce Inf by 0
            
            P=P/sum(P);
            
            % Roulette Wheel Selection
            r=rand;
    
            C=cumsum(P);
    
            j=find(r<=C,1,'first');
            
            ant(k).Tour=[ant(k).Tour j];
            
        end
        
        % Calculate tardiness for the sequence
        tardiness = [];     % Array to store tardiness for each node(job)
        
        cumm_time = 0;      % The cummulative time elapsed
        for node = ant(k).Tour
            cumm_time = cumm_time + processing_time(node);
            tardiness = [tardiness max(0, cumm_time-due_date(node))];
        end
        
        % Tardiness of sequence, T(x) = sum of tardiness of individual jobs
        ant(k).Tardiness = sum(tardiness);

        %% Pheromone Deposit Function
        Y = 100/sum(tardiness);     % Y = 100 / T(x)
    end
    
    %% Update Pheromones
    for k=1:nAnt
        
        tour=ant(k).Tour;
        n=numel(tour);

        % Keeping the cost as the total tardiness, T(x)
	    ant(k).Cost = ant(k).Tardiness;

        % Adding Y, to the corresponding edge, in the pheromone matrix
        for l=1:nVar-1
            
            i=tour(l);
            j=tour(l+1);
            
            tau(i,j)=tau(i,j)+Y;
            
        end
        
        % Storing the best ant (solution) obtained till now
        if ant(k).Cost<BestSol.Cost
            BestSol=ant(k);
        end
        
    end
    
    % Evaporation
    tau=(1-evp)*tau;
    
    % Store Best Cost
    BestCost(it)=BestSol.Cost;
    
    % Show Iteration Information
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    
    % Printing the best solution, BestSol structure, at end of all iterations
    if it==MaxIt
        BestSol
    end

end

%% Results
% Plotting best cost vs iterations graph
figure;
plot(BestCost,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
grid on;