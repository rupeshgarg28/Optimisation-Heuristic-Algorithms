% Assignment 2
% RUPESH GARG
% 19IM30019

clear
clc
close all
%Lower and upper bounds
Lb = [-3 -3];
Ub = [3 3];
u0 = [-1.5 1.5]; 
%d = length(Lb); 

%SA Parameters
T_init = 1; %Initial Temperature 
max_run = 100; %Max No of runs 
k = 1; %Boltzman constant
T_min = 0.000001; %Min temp for cooling
alpha= 0.73; %cooling factor
opt=[];eval=[];temp=[];best_sol=[];
max_rej = 800; % max no of rejections
max_accept = 10; % max no of accepts at a temp
initial_search = 100; % initial search period
stepsize_localsearch = [0.1 0.1];
%Initializing Counters and values
i = 0; j = 0; totaleval = 0; accept = 0;
T = T_init;
E_init = fobj(u0); 
E_old = E_init; 
E_new= E_old;
best = u0;
%Main Program 
while (T>T_min && j<max_rej)
    i=i+1;
    %Max numbers of runs
    if(i>=max_run || accept>=max_accept)
        %reset counters
        i=1;
        accept=0;
        %cooling according to cooling schedule
        T=cooling(alpha,T);
    end
    
    if (totaleval<=initial_search)
        ns=newsolution1(u0,Lb,Ub);
    else
        ns=newsolution2(best,Lb,Ub,stepsize_localsearch);
    end

    totaleval = totaleval+1;
    E_new=fobj(ns);
    %Accepting or rejecting a solution
    DeltaE=E_new-E_old;
    %Accept if improved
    if(DeltaE<0)
        best=ns;
        E_old = E_new;
        accept=accept+1;
    % Accept with a probability if not improved
    elseif (DeltaE>=0 && exp(-DeltaE/(k*T))>rand)
        best = ns;
        E_old = E_new;
        accept=accept+1;
    else
        j=j+1;
    end
    %Update the estimated optimal soln
    f_opt=E_old;
    opt=[opt;f_opt]; eval=[eval;totaleval];temp=[temp;T];best_sol=[best_sol;best];
end

bestsol=best;
f_val=f_opt;
N=totaleval;
tab=table(bestsol,f_val,N)
%M= [best_sol, opt]

figure
%convergaence curve-2d
subplot(2,2,1)
plot(eval,opt)
xlabel('No of iteration')
ylabel('functional evalution f(x)')

%Cooling curve-2d
subplot(2,2,2)
plot(eval,temp,'--r')
xlabel('No of iteration')
ylabel('Temperature')
subplot(2,2,3)

%Function curve-3d
stepSize = [0.05 , 0.05];
x = Lb(1):stepSize(1):Ub(1);
y = Lb(2):stepSize(2):Ub(2);
[x_new , y_new] = meshgrid(x,y);
for i = 1: length(x)
    for j = 1 : length(y)
        X = [x_new(i,j) , y_new(i,j)];
        z_new(i,j) = fobj(X);
    end
end
surfc(x_new, y_new, z_new)
hold on
xlabel('x')
ylabel('y')
zlabel('f(x)')
colormap jet
box on

%Contour plot with start and end solution 
subplot(2,2,4)
hold on
pcolor(x_new, y_new, z_new)
view(0,90)
plot(u0(1), u0(2),'-ok', 'markerSize' , 10 , 'markerFaceColor', 'k')
plot(best_sol(end,1), best_sol(end,2), '- dk', 'markerSize' , 10 , 'markerFaceColor', 'c')
shading flat
colormap jet