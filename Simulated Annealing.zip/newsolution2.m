% Assignment 2 
% RUPESH GARG
% 19IM30019

function s= newsolution2(best,Lb,Ub,stepsize_localsearch)

% local search
if length(Lb)>0 
    s= best+stepsize_localsearch.*randn(1);
end
for i = 1:length(best)
    if (s(i)>Ub(i))
        s(i)=Ub(i)
    end
    if (s(i)<Lb(i))
        s(i)=Lb(i)
    end
end
ns=s;