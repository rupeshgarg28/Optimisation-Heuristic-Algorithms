%ASSIGNMENT 2
%19IM30019
%Rupesh Garg
clc
clear all
close all
lb = [-1 -1];
ub = [1  1];
stepSize = [0.05 , 0.05]
x = lb(1):stepSize(1):ub(1);
y = lb(2):stepSize(2):ub(2);
[x_new , y_new] = meshgrid(x,y);

for i = 1: length(x)
    for j = 1 : length(y)
        X = [x_new(i,j) , y_new(i,j)];
        z_new(i,j) = fobj(X);
    end
end
figure
subplot(1,2,1)
surfc(x_new, y_new, z_new)
hold on
xlabel('x')
ylabel('y')
zlabel('f(x)')
colormap jet
box on
