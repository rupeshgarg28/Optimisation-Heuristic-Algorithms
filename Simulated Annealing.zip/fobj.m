%ASSIGNMENT 2
%19IM30019
%Rupesh Garg
%objective function 
function z = fobj(u)
%z= 500-20*u(1)-26*u(2)-4*u(1)*u(2)+4*u(1).^2+3*u(2).^2
%z=(1-u(1))^2+100*(u(2)-u(1).^2).^2
z = -5/1+u(1).^2+u(2).^2 + sin(cot(exp(-5/1+u(1).^2+u(2).^2)));