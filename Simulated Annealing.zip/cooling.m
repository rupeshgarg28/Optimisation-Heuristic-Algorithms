%ASSIGNMENT 2
%19IM30019
%Rupesh Garg
% Cooling schedule 
function T= cooling(alpha,T)
T= alpha*T;