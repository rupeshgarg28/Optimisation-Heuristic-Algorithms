%Rupesh Garg
%19IM30019

function penalty = constraint(x1,x2,x3)
    multiplier = 30;    %Penalty 30%
    constraint1 = x1 + x2 + x3 - 5;  
    constraint2 = x1^2 + 2*x2 - x3;
    penalty = 0;
    if constraint1 >0
        penalty = penalty + multiplier*constraint1;
    end
    if constraint2 >0
        penalty = penalty + multiplier*constraint2;
    end
   
end