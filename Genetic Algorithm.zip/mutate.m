%Rupesh Garg
%19IM30019
function pop_new = mutate(pop_new, Dpop, o)

mutation = 0.02;
if mutation>rand
pop_new(o, :) = pop_new (o, :) .* rand(1, Dpop);
end

end