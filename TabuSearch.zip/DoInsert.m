%Assignment 3
%19IM3009
%Rupesh Garg

function q=DoInsert(p,i1,i2)
    q=p([1:i1-1 i1+1:i2 i1 i2+1:end]);

end