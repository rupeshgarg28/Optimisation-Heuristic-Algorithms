%Assignment 3
%19IM3009
%Rupesh Garg

function model=CreateModel()

    x=[1 2 3 4 5];
    
    y=[1 2 3 4 5];

    c=[0 132 217 164 158; 132 0 290 201 79; 217 290 0 201 79;164 201 113 0 196; 158 79 303 196 0];
    
    n=numel(x);
    
    d=zeros(n,n);
    
    for i=1:n-1
        for j=i+1:n
            d(i,j)=c(i,j);
            d(j,i)=c(j,i);
        end
    end

    xmin=0;
    xmax=100;
    
    ymin=0;
    ymax=100;
    
    model.n=n;
    model.x=x;
    model.y=y;
    model.d=d;
    model.xmin=xmin;
    model.xmax=xmax;
    model.ymin=ymin;
    model.ymax=ymax;
    
end