%Rupesh Garg
%19IM30019

function [ o ] = objectiveFunction(x)

o = -(2*x(1).^2 - x(2).^2);

end
