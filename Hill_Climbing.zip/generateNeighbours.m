%Rupesh Garg
%19IM30019

function [ Neighbours ] = generateNeighbours(current_Sol , stSize,  lb, ub)


nVariable = length(stSize);

idx = 0;
    for i = 1 : nVariable
        idx = idx + 1;
       
        st_Vec = zeros(1,nVariable);
        st_Vec(i) = stSize(i);
        Neighbours( idx ).pos = current_Sol.pos + st_Vec;
       
        
        if Neighbours( idx ).pos(i) > ub(i)
            Neighbours( idx ).pos(i) = ub(i);
        end
        if Neighbours( idx ).pos(i) < lb(i)
            Neighbours( idx ).pos(i) = lb(i);
        end
       
        Neighbours( idx ).cost       = objectiveFunction(Neighbours( idx ).pos);
       
        idx = idx + 1;
       
        st_Vec = zeros(1,nVariable);
        st_Vec(i) = stSize(i);
        Neighbours( idx ).pos = current_Sol.pos - st_Vec;
       
        if Neighbours( idx ).pos(i) > ub(i)
            Neighbours( idx ).pos(i) = ub(i);
        end
        if Neighbours( idx ).pos(i) < lb(i)
            Neighbours( idx ).pos(i) = lb(i);
        end
       
        Neighbours( idx ).cost       = objectiveFunction(Neighbours( idx ).pos);
    end
