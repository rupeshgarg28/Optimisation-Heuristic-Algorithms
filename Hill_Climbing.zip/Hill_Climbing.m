%Rupesh Garg
%19IM30019

clear all
close all
clc

initial =  [-0.5,0.9] ;
c_in = objectiveFunction(initial);

lb = [-1 -1];
ub = [1 1];

stSize = [0.05 , 0.05];

nVariable = length(initial);

minFound = 0;

A.pos = initial;
A.cost = c_in;

itr = 0;

while minFound == 0
    imp = 0;
   
    itr = itr + 1;
    traj(itr).pos = A.pos;
    traj(itr).cost = A.cost;
   
    Neighbours = generateNeighbours(A , stSize, lb, ub);
   
    for k = 1 : length(Neighbours)
        B = Neighbours( k );
        if B.cost > A.cost
            imp  = 1;
            A.cost = B.cost;
            A.pos = B.pos;
        end
    end
   
    if imp == 0
        minFound = 1;
        traj(itr).pos = A.pos;
        traj(itr).cost = A.cost;
    end
end

A.pos
A.cost

figure
set(gcf,'position' , [50,50,700,700])


subplot(2,2,1)

x = lb(1):stSize(1):ub(1);
y = lb(2):stSize(2):ub(2);

[x_new , y_new] = meshgrid(x,y);

for i = 1: length(x)
    for j = 1 : length(y)
        X = [x_new(i,j) , y_new(i,j)];
        z_new(i,j) = objectiveFunction(X);
    end
end
surfc(x_new, y_new, z_new)
hold on
xlabel('x1')
ylabel('x2')
zlabel('Cost')
shading faceted
colormap jet
box off


for k = 1 : length(traj)
    tranFinal_x(k) = traj(k).pos(1);
    trajFinal_y(k) = traj(k).pos(2);
    trajFinal_z(k) = traj(k).cost;
end
plot3(tranFinal_x,trajFinal_y,trajFinal_z, '--b', 'lineWidth' , 1)
plot3(initial(1),initial(2),c_in, 'dk', 'markerSize' , 8 , 'markerFaceColor', 'b')
plot3(tranFinal_x(end),trajFinal_y(end),trajFinal_z(end), '- dk', 'markerSize' , 8 , 'markerFaceColor', 'b')


subplot(2,2,2)
hold on
pcolor(x_new, y_new, z_new)
view(0,90)
plot(tranFinal_x,trajFinal_y, '- .b', 'lineWidth' , 2)
plot(initial(1),initial(2), '-dk', 'markerSize' , 8 , 'markerFaceColor', 'b')
plot(tranFinal_x(end),trajFinal_y(end), '- dk', 'markerSize' , 8 ,'markerFaceColor', 'b')
shading flat
colormap colorcube


subplot(2,2,[3 4])
plot([traj.cost] );
xlabel('Iteration')
ylabel('Cost')
